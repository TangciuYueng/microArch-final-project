create definer = social@`%` trigger limit_intimacy_range
    before update
    on friend
    for each row
BEGIN
    -- 检查新值是否小于0，如果是，将其设置为0
    IF NEW.intimacy < 0.00 THEN
        SET NEW.intimacy = 0.00;
    -- 检查新值是否大于100，如果是，将其设置为100
    ELSEIF NEW.intimacy > 100.00 THEN
        SET NEW.intimacy = 100.00;
    END IF;
END;

